class Go extends Game {
	public void playGame() {
		System.out.println("I'm playing Go");
	}
}