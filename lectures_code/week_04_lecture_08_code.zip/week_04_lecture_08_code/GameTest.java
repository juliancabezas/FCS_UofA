class GameTest {
	public static void main(String[] args) {
		Chess chessGame = new Chess();
		chessGame.welcome();
		chessGame.playGame();
		chessGame.printResult();
		chessGame.save();

		System.out.println("-----------");
		Go goGame = new Go();
		goGame.welcome();
		goGame.playGame();
	}
}