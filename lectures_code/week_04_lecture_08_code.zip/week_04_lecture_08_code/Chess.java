class Chess extends Game implements Saveable { 
	public void playGame() {
		System.out.println("I'm playing chess");
	}

	public void printResult() {
		System.out.println("Chess game is over; the winner is " + this.player1);
	}

	public void save(){
		System.out.println("Chess game is saved");
	}

	public void load(){
		System.out.println("Chess game is loaded");
	}
}