class PersonTest {
	public static void main(String[] args) {
		Person person1 = new Person();
		person1.display();

		Person person2 = new Person("Elon Mask", 48, "How to Rule the World");
		person2.display();

		// person2 = new Person();
		// person2.display();

		Person person3 = new Person("Mickey Mouse");
		person3.display();

		Person person4 = new Person(99);
		person4.display();
	}
}