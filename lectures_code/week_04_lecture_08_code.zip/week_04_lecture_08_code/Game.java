abstract class Game {
	public String player1; 
	public String player2;

	Game() {
		this.player1 = "Player 1";
		this.player2 = "Player 2";
	}

	public void welcome() {
		System.out.println("Hello " + this.player1 + " and " + this.player2);
	} 

	public abstract void playGame();
}