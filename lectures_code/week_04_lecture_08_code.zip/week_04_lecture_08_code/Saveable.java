interface Saveable {
	public void save();
	public void load();
}