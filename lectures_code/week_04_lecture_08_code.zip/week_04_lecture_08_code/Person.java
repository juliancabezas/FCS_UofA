class Person {
	// Attributes
	private String name;
	private int age;
	private String favBook;

	// Constructors
	
	// Person() {
	// 	this.name = null;
	// 	this.age = 0;
	// 	this.favBook = null;
	// }

	// No-argument constuctor - basic
	// Person() {
	// 	System.out.println("Calling no-arg constuctor");
	// 	this.name = "unknown";
	// 	this.setAge(1);
	// 	this.favBook = "Harry Potter";
	// }

	// Parametrized
	Person(String name, int age, String favBook) {
		System.out.println("Calling parametrized constuctor");
		this.setName(name);
		this.setAge(age);
		this.setFavBook(favBook);
	}

	Person(String name) {
		this(); // Calling no-arg constructor
		System.out.println("Calling name constuctor");
		this.setName(name);
	}

	Person(int age) {
		this("default name"); // Calling constructor Person(String name)
		System.out.println("Calling age constuctor");
		this.setAge(age);
	}

	// Won't work, we already have Person(String) constructor
	// Person(String favBook) {
	// 	this.setFavBook(favBook);
	// }

	// Methods
	public void display() {
		System.out.println("Name: " + this.name);
		System.out.println("Age: " + this.age);
		System.out.println("Fav Book: " + this.favBook);
		System.out.println();
	}

	// Accessors
	public String getName() {
		return this.name;
	}

	public int getAge() {
		return this.age;
	}

	public String getFavBook() {
		return this.favBook;
	}

	// Mutators
	public void setName(String name) {
		this.name = name;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public void setFavBook(String favBook) {
		this.favBook = favBook;
	}
}