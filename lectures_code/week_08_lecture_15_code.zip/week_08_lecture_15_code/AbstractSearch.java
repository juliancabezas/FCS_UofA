abstract class AbstractSearch {
	abstract int search(int[] array, int item);
	abstract int search(Student[] array, Student item);
}