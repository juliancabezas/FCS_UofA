public class Charmander extends Pokemon {
	/* You can implement this class as your own exercise*/
}