class Test {
	public static void main(String[] args) {
		int res = Menu.readInput();
		System.out.println(res);
	}
}