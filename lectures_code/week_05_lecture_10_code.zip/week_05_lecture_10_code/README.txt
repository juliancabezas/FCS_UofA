1) abstract class ArithmeticOperation - base
Child classes:
1.1) Sum
1.2) Sub
1.3) Mul
1.4) Div

2) Menu

3) CalculatorApplication - executable file