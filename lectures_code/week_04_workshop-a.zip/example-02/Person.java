public class Person{
	private String name;
	private int age;

	public void setName(String tmpName){
		this.name = tmpName;
	}
	public void setAge(int tmpAge){
		this.age = tmpAge;
	}

	public String getName(){
		return this.name;
	}
	public int getAge(){
		return this.age;
	}

}