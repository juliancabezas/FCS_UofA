public class Main{
	public static void main(String []args){
		
		Person person1 = new Person();
		person1.setName("John Smith");
		person1.setAge(21);
		System.out.println("Name: " + person1.getName()
			+ " Age: " + person1.getAge());

		Person person2 = new Person();
		person2.setName("Mariah Carey");
		person2.setAge(22);
		System.out.println("Name: " + person2.getName()
			+ " Age: " + person2.getAge());


	}
}