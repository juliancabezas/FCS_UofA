public class Main{
	public static void main(String[] args){
		Person person1 = new Person();
		person1.name = "Rafa";
		person1.age = 19;
		System.out.println("Name:" + person1.name + " "
						  +"Age: " + person1.age);

		Person person2 = new Person();
		person2.name = "Barack Obama";
		person2.age = 105;
		System.out.println("Name:" + person2.name + " "
							+"Age: " + person2.age);

		Person person3 = new Person();
		person3.name = "Justin Bieber";
		person3.age = 12;
		System.out.println("Name:" + person3.name + " "
							+"Age: " + person3.age);
	}
}